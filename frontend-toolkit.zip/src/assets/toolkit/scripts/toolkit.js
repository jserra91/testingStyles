/******/ (function (modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if (installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
			/******/
};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
		/******/
}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
	/******/
})
/************************************************************************/
/******/([
/* 0 */
/***/ function (module, exports) {

			/**
			 * Toolkit JavaScript
			 */

			'use strict';

			$(document).ready(function () {

				$('.alz-wm-checkbox-button').click(function (e) {
					if (!$(this).hasClass("disabled")) {
						if (!$(this).find('.alz-wm-checkbox-button-input').is(":checked")) {
							$(this).find('.alz-wm-checkbox-button-input').prop('checked', false);
						} else {
							$(this).find('.alz-wm-checkbox-button-input').prop('checked', true);
						}
					}
				});

				// checkboxbutton
				$("button[class^='alz-btn-checkboxbutton']").click(function (e) {
					var _val = $(this).hasClass('checked');
					if (_val) {
						$(this).removeClass('checked');
						$(this).val('notchecked');
					} else {
						$(this).addClass('checked');
						$(this).val('ischecked');
					}
				});

				//Comprobamos el navegador
				var doc = document.documentElement;
				doc.setAttribute('data-useragent', navigator.userAgent);

				// String functions
				if (!String.prototype.startsWith) {
					String.prototype.startsWith = function (searchString, position) {
						position = position || 0;
						return this.indexOf(searchString, position) === position;
					};
				}

				if (!String.prototype.endsWith) {
					String.prototype.endsWith = function (searchString, position) {
						var subjectString = this.toString();
						if (position === undefined || position > subjectString.length) {
							position = subjectString.length;
						}
						position -= searchString.length;
						var lastIndex = subjectString.indexOf(searchString, position);
						return lastIndex !== -1 && lastIndex === position;
					};
				}

				//TOOLTIP & POPOVER
				$('[data-toggle="tooltip"]').tooltip();
				$('[data-toggle="popover"]').popover({
					container: 'body'
				});

				var openPopup;

				$('[data-toggle="popover"]').on('click', function () {
					if (openPopup) {
						$(openPopup).popover('hide');
					}
					openPopup = this;
				});

				var popupPlace;

				$(".alz-wm-info-po-link").click(function () {
					$('.alz-wm-info-po-markup > .alz-wm-info-po-link').not(this).popover('hide');
					popupPlace = $(this).attr('class').split(' ').pop();
				});

				$('.alz-wm-info-po-markup > .alz-wm-info-po-link').popover({
					trigger: 'click',
					html: true,
					title: function title() {
						return $(this).parent().find('.alz-wm-info-po-title').html();
					},
					content: function content() {
						return $(this).parent().find('.alz-wm-info-po-body').html();
					},

					container: 'body',
					placement: function placement() {
						return popupPlace;
					}

				});

				$(".alz-info-po-link").click(function () {
					$('.alz-info-po-markup > .alz-info-po-link').not(this).popover('hide');
					popupPlace = $(this).attr('class').split(' ').pop();
				});

				$('.alz-info-po-markup > .alz-info-po-link').popover({
					trigger: 'click',
					html: true,
					title: function title() {
						return $(this).parent().find('.alz-info-po-title').html();
					},
					content: function content() {
						return $(this).parent().find('.alz-info-po-body').html();
					},

					container: 'body',
					placement: function placement() {
						return popupPlace;
					}

				});

	    //BUTTON GROUP
	    /*$(".alz-wm-btn-group > .alz-wm-bs-btn-group").click(function (e) {
	        var deshabilidado = $(this).children('button').attr('disabled');
	        if (deshabilidado != 'disabled') {
	        	var input = $(this).find('input');
	        	var radioname = $(input).attr("name");
	        	if ($(input).attr("radioType") == "M") {
	    			radioname = radioname.substring(0, radioname.length-1);
	    		}
	        	controlsButtonGroup.setValue(radioname, $(input).val())
	        } else {
	            e.stopPropagation();
	        }
	    });*/

				//COLLAPSE CARET
				window.upturnCaret = function () {
					$(this).parent().find(".allianz-icon-chevron-down").removeClass("allianz-icon-chevron-down").addClass("allianz-icon-chevron-up");
					Page.doEPacResize();
					try {
						controlsTable.refreshTableInsideSection($(this));
					} catch (e) {
					}
				};

				window.downturnCaret = function () {
					$(this).parent().find(".allianz-icon-chevron-up").removeClass("allianz-icon-chevron-up").addClass("allianz-icon-chevron-down");
					Page.doEPacResize();
				};

				$('.collapse').on('shown.bs.collapse', window.upturnCaret).on('hidden.bs.collapse', window.downturnCaret);

				// BUTTON IMAGE
				$('.alz-wm-btn-image').has('br').addClass('alz-wm-btn-image-2line');

				$('.alz-btn-image').has('br').addClass('alz-wm-btn-image-2line');

				//BUTTONS 2 LINES
				$('.btn.alz-wm-btn').has('br').each(function () {
					var str = $(this).html();
					var res = str.split("<br>");
					if (res.length > 2) {
						$(this).addClass('alz-wm-button-multiline');
					} else {
						$(this).addClass('alz-wm-btn-2line');
					}
				});

				$('.btn.alz-btn').has('br').each(function () {
					var str = $(this).html();
					var res = str.split("<br>");
					if (res.length > 2) {
						$(this).addClass('alz-wm-button-multiline');
					} else {
						$(this).addClass('alz-wm-btn-2line');
					}
				});

				/* INFODATA */
				function showinputdata(idcollapse, idboton) {
					if ($('#' + idcollapse).hasClass('alz-wm-infoData-visible')) {
						$('#' + idcollapse).slideUp();
						$('#' + idcollapse).removeClass('alz-wm-infoData-visible').addClass('alz-wm-infoData-hidden');
						$('#' + idboton).removeClass('allianz-icon-close').addClass('allianz-icon-info');
					} else {
						$('#' + idcollapse).slideDown();
						$('#' + idcollapse).removeClass('alz-wm-infoData-hidden').addClass('alz-wm-infoData-visible');
						$('#' + idboton).removeClass('allianz-icon-info').addClass('allianz-icon-close');
					}
				}

				$(".alz-wm-infoData-clickable").click(function () {
					showinputdata($(this).prev().attr('id'), $(this).find('.alz-wm-infoData-container-icon-span').attr('id'));
				});

				// OPTIMIZADOR IMAGEN
				$('.alz-input-file-btn').click(function () {
					// ID of the input file is id removing suffix "_facade_btn" (11 characters).
					var idInputFile = this.id.substring(0, this.id.length - 11);

					var elem = document.getElementById(idInputFile);
					if (elem && document.createEvent) {
						var evt = document.createEvent("MouseEvents");
						evt.initEvent("click", true, false);
						elem.dispatchEvent(evt);
					}
				});

				$('.alz-input-file-hidden').change(function () {
					var filename = "";
					if (this.files && this.files[0] && this.files[0].name) {
						filename = this.files[0].name;
					}

					var newId = this.id + '_facade';
					$(pointerof(newId)).val(filename);
				});

				/* LIGHTBOX */
				$('.modal').modal({
					show: false,
					backdrop: 'static',
					keyboard: false
				});

				$('.modal').on('show.bs.modal', function (e) {
					if (window.top != window.self) {
						var iframes = window.parent.document.getElementsByTagName('iframe');
						var offsetTop = 0;
						for (var i = 0; i < iframes.length; i++) {
							if (iframes[i] == window.frameElement) {
								offsetTop = $(iframes[i]).offset().top;
								break;
							}
						}
						var offset = window.top.pageYOffset - offsetTop;
						if (offset < 0) offset = 0;
						$(e.currentTarget).css('top', offset);
						$(e.currentTarget).attr('style', function (index, value) {
							return value + "overflow-y: hidden !important;";
						});
					}
				});

				/* INPUT_ACCOUNT - IBAN */
				// This has to be here (instead of entryAccount.js) so that it will execute _before_ maskinput.js events.
				$(".iban-wm").keypress(function (e) {
					if (e.which >= 97 && e.which <= 122 && entryInputAccountIBAN.inputIBAN_isUppercaseLetterMask(this)) {
						var newKey = e.which - 32;

						e.keyCode = newKey;
						e.charCode = newKey;
						e.which = newKey;
					}
				});

				//IDENTIFICATION NUMBER
				$(function () {
					$.mask.definitions['~'] = "[+-]";
					$.mask.definitions['A'] = "[A-Z]";
					$(".identification-dni").mask("99999999A", { placeholder: "00000000Z" });
				});

				//CHECKBOXBUTTON
				$(".alz-wm-group-cbbutton-single:enabled").click(function () {
					$(this).toggleClass("active");
					if ($(this).val() == 'notchecked') {
						$(this).removeClass('alz-wm-checkboxbutton-notchecked').addClass("alz-wm-checkboxbutton-checked");
						$(this).find('.allianz-icon-ok').removeClass('alz-wm-icon-hidden');
						$(this).val('ischecked');
					} else {
						$(this).removeClass('alz-wm-checkboxbutton-checked').addClass("alz-wm-checkboxbutton-notchecked");
						$(this).find('.allianz-icon-ok').addClass('alz-wm-icon-hidden');
						$(this).val('notchecked');
						$(this).removeClass('active');
					}
					var inputId = $(this).find('input').attr("id");
					controlsButtonCheckBox.toggle(inputId);
				});

				//TRUNCATE TABLE
				$("div.alz-wm-tt-container").on("click", "div.alz-wm-tt-content", function () {
					$(this).parent().parent().find('.alz-wm-tt-selected').removeClass('alz-wm-tt-selected');
					$(this).addClass('alz-wm-tt-selected');

					var idinput = $(this).parent().parent().parent().find('.alz-wm-tt-input-hidden').attr('id');

					var idstring = $(this).attr('id');

					var numbervalue = idstring.split('_row_');

					$('#' + idinput).val(numbervalue[1]);
				});

				function showwmttcollapse(idcollapse, idboton, spanmore, spanless) {
					if ($('#' + idcollapse).hasClass('alz-wm-tt-hidden')) {
						$('#' + idcollapse).slideDown(function () {
							Page.doEPacResize();
						});
						$('#' + idcollapse).removeClass('alz-wm-tt-hidden');
						$('#' + idboton).removeClass('allianz-icon-chevron-down').addClass('allianz-icon-chevron-up');
						$('#' + spanmore).addClass('alz-wm-tt-hidden');
						$('#' + spanless).removeClass('alz-wm-tt-hidden');
					} else {
						$('#' + idcollapse).slideUp(function () {
							Page.doEPacResize();
						});
						$('#' + idcollapse).addClass('alz-wm-tt-hidden');
						$('#' + idboton).removeClass('allianz-icon-chevron-up').addClass('allianz-icon-chevron-down');
						$('#' + spanmore).removeClass('alz-wm-tt-hidden');
						$('#' + spanless).addClass('alz-wm-tt-hidden');
					}
				}

				$(".alz-wm-tt-collapse-button").click(function () {
					showwmttcollapse($(this).parent().prev().attr('id'), $(this).find('.allianz-icon').attr('id'), $(this).find('.alz-wm-tt-span-more').attr('id'), $(this).find('.alz-wm-tt-span-less').attr('id'));
				});

				//DISABLEDBUTTONS
				$(".alz-wm-btn-image").click(function (e) {
					e.preventDefault();
				});

				$(".alz-group-button").click(function (e) {
					e.preventDefault();
				});

				$(".alz-wm-group-button").click(function (e) {
					e.preventDefault();
				});

				//BOOTSTRAP SIZES

				$('#exampleTamanos').on('change', function () {
					var bodydocument = $(document).find('body');
					var tamanoelegido = $(this).val();
					switch (tamanoelegido) {
						case 'lg':
							$(bodydocument).removeClass('body-md').removeClass('body-sm').removeClass('body-xs').addClass('body-lg');
							break;
						case 'md':
							$(bodydocument).removeClass('body-lg').removeClass('body-sm').removeClass('body-xs').addClass('body-md');
							break;
						case 'sm':
							$(bodydocument).removeClass('body-md').removeClass('body-lg').removeClass('body-xs').addClass('body-sm');
							break;
						case 'xs':
							$(bodydocument).removeClass('body-md').removeClass('body-sm').removeClass('body-lg').addClass('body-xs');
							break;
					}
				});

				//MENU
				/*
				 * mobile WM Menu
				 * 
				 */
				$('#mobileMenu li.anterior').on('click', function (e) {
					e.stopPropagation();
					$(this).closest('div').addClass('hidden');
				});
				$('#mobileMenu li').not('#mobileMenu li.submenu').on('click', function (e) {
					$(this).parent().children("div").addClass('hidden');
				});

				$('#mobileMenu li.submenu a').on('click', function (e) {
					$(this).parent().children("div").removeClass('hidden');
					var onclick = $(this).attr("onclick");
					if (onclick != undefined && onclick !== "") {
						expandMenu();
					}
				});

				$('span.alz-wm-menu-xsmenu').on('click', function (e) {
					$("#mobileMenu .alz-wm-menu-mobile-collapse").children("div").addClass('hidden');
					$("#mobileMenu").children().first("ul.alz-wm-menu-mobile-collapse-hidden").removeClass('alz-wm-menu-mobile-collapse-hidden').addClass('alz-wm-menu-mobile-collapse');
				});

				/*
				 * Desktop WM Menu
				 * 
				 */
				$('#desktopMenu a').not('.submenu a').not('.submenu2 a').not('.submenu3 a').on('click', function (e) {
					var h = $("#desktopMenu .activeSubmenu ul").height();
					$("#desktopMenu .activeSubmenu").height(h);
					if ($("#desktopMenu *").hasClass("active")) {
						$("#desktopMenu *.active").removeClass('active');
					}
					if ($("#desktopMenu *").hasClass("activeSubmenu")) {
						if ($(this).parent().children('div:first').hasClass("activeSubmenu")) {
							cleanDesktopMenu();
							$(this).parent().children('#desktopMenu span.glyphicon-triangle-top').addClass('hidden');
						} else {
							cleanDesktopMenu();
							$(this).parent().children('#desktopMenu span.glyphicon-triangle-top').removeClass('hidden');
							$(this).parent().children('div:first').addClass('activeSubmenu');
							$(this).addClass("active");
							$(this).parent().children('div:first').removeClass('alz-wm-menu-dropdown-mobile-collapse-hidden').addClass('alz-wm-menu-dropdown-mobile-collapse');
						}
					} else {
						cleanDesktopMenu();
						$(this).addClass("active");
						$(this).parent().children('div:first').addClass('alz-wm-menu-dropdown-mobile-collapse').removeClass('alz-wm-menu-dropdown-mobile-collapse-hidden');
						$(this).parent().children('#desktopMenu span.glyphicon-triangle-top').removeClass('hidden');
						$(this).parent().children('div:first').addClass('activeSubmenu');
					}
				});

				$('#desktopMenu .submenu a').not('.submenu2 a').not('.submenu3 a').on('click', function (e) {
					if ($(this).parent().children('div:first').hasClass("alz-wm-menu-mobile-collapse-hidden")) {
						if ($("#desktopMenu *").hasClass("activeSubmenu1")) {
							$("#desktopMenu *.active1").removeClass("active1");
							$("#desktopMenu *.activeSubmenu1").removeClass('alz-wm-menu-mobile-collapse').addClass('alz-wm-menu-mobile-collapse-hidden');
							$("#desktopMenu *.activeSubmenu1").removeClass('activeSubmenu1');
							$(this).addClass("active1");
							var h = $("#desktopMenu .activeSubmenu ul").height();
							$("#desktopMenu .activeSubmenu").height(h);
						}
						$(this).parent().children('div:first').addClass('activeSubmenu1');
						$(this).addClass("active1");
						$(this).parent().children('div:first').addClass('alz-wm-menu-mobile-collapse').removeClass('alz-wm-menu-mobile-collapse-hidden');
						//escondemos cuarto nivel si lo había abierto
						$("#desktopMenu *.activeSubmenu2").removeClass('alz-wm-menu-mobile-collapse').addClass('alz-wm-menu-mobile-collapse-hidden');
						var h = $("#desktopMenu .activeSubmenu1").height();
						if (h > $("#desktopMenu .activeSubmenu").height()) {
							$("#desktopMenu .activeSubmenu").height(h);
						}
					} else {
						$(this).parent().children('div:first').removeClass('activeSubmenu1');
						$(this).removeClass("active1");
						$(this).parent().children('div:first').removeClass('alz-wm-menu-mobile-collapse').addClass('alz-wm-menu-mobile-collapse-hidden');
						var h = $("#desktopMenu .activeSubmenu ul").height();
						$("#desktopMenu .activeSubmenu").height(h);
					}
				});
				$('#desktopMenu .submenu2 a').not('#desktopMenu .submenu3 a').on('click', function (e) {
					if ($(this).parent().children('div:first').hasClass("alz-wm-menu-mobile-collapse-hidden")) {
						if ($("#desktopMenu *").hasClass("activeSubmenu2")) {
							$("#desktopMenu *.activeSubmenu2").removeClass('alz-wm-menu-mobile-collapse').addClass('alz-wm-menu-mobile-collapse-hidden');
							$("#desktopMenu *.activeSubmenu2").removeClass('activeSubmenu2');
							$(this).removeClass("active1");
						}
						$(this).parent().children('div:first').addClass('activeSubmenu2');
						$(this).addClass("active1");
						$(this).parent().children('div:first').addClass('alz-wm-menu-mobile-collapse').removeClass('alz-wm-menu-mobile-collapse-hidden');
						var h = $("#desktopMenu .activeSubmenu2").height();
						if (h > $("#desktopMenu .activeSubmenu").height()) {
							$("#desktopMenu .activeSubmenu").height(h);
						}
					} else {
						$(this).parent().children('div:first').removeClass('activeSubmenu2');
						$(this).removeClass("active1");
						$(this).parent().children('div:first').removeClass('alz-wm-menu-mobile-collapse').addClass('alz-wm-menu-mobile-collapse-hidden');
						var h = $("#desktopMenu .activeSubmenu1 ul").height();
						if (h > $("#desktopMenu .activeSubmenu ul").height()) {
							$("#desktopMenu .activeSubmenu").height(h);
						}
					}
					if ($(this).children().hasClass("alz-wm-menu-mobile-collapse-hidden")) {
						cleanDesktopMenu();
						$('#desktopMenu span.glyphicon-triangle-top').addClass('hidden');
					}
				});
				$('#desktopMenu .submenu3 a').on('click', function (e) {
					if ($(this).children().hasClass("alz-wm-menu-mobile-collapse-hidden")) {
						cleanDesktopMenu();
						$('#desktopMenu span.glyphicon-triangle-top').addClass('hidden');
					}
				});
				$('#desktopMenu a').on('click', function (e) {
					var onclick = $(this).attr("onclick");
					if (onclick != undefined && onclick !== "") {
						cleanDesktopMenu();
						$('#desktopMenu span.glyphicon-triangle-top').addClass('hidden');
					}
				});

				//BREADCRUMB	

				//actualizar breadcrumb y opcion menu seleccionada al recargar página
				if ($('.alz-wm-blue-menu').is(':visible') || $('.alz-wm-menu').is(':visible')) {
					inicializarMenu();
				}

				var strMenu = "";
				var strSubmenu = "";
				var strSubmenu2 = "";
				var strSubmenu3 = "";
				var arrayBreadcrumb = [strMenu, strSubmenu, strSubmenu2, strSubmenu3];

				function inicializarMenu() {
					//accedemos al valor nextMenuSelected (id del menu seleccionado o al que se debia ir al siguiente paso)
					if (document.getElementById("nextMenuSelected") != null) {
						var menuSel = document.getElementById("nextMenuSelected").value;
						//encontramos el menú superior
						$('#' + menuSel).closest('.alz-wm-menu-dropdownHeader').children('a:first').addClass('active');
						//montamos breadcrumb
						strMenu = $('#' + menuSel).closest('.alz-wm-menu-dropdownHeader').children('a:first').html();
						strSubmenu = $('#' + menuSel).parents('li.submenu:first').children('a:first').html();
						strSubmenu2 = $('#' + menuSel).closest('li.submenu2').children('a:first').html();
						strSubmenu3 = $('#' + menuSel).closest('li.submenu3').children('a:first').html();
						arrayBreadcrumb = [strMenu, strSubmenu, strSubmenu2, strSubmenu3];
						actualizarBreadcrumb(arrayBreadcrumb, "init");
					}
				}

				function actualizarBreadcrumb(arrayBreadcrumb, onclick) {
					if (onclick != undefined && onclick !== "") {
						var array = arrayBreadcrumb.toString().split(',');
						//renderizamos breadcrumb				
						var htmlBreadcrumb = '<ol class="breadcrumb">\n';
						//pintamos hasta el penúltimo elemento (de los niveles 1 al 3)
						for (var i = 0; array[i + 1] !== "" && i < 3; i++) {
							htmlBreadcrumb = htmlBreadcrumb + '<li><a href="#">' + array[i] + '</a></li>\n';
						}
						//ultimo elemento es distinto
						//no mostramos si solo hay un nivel en la versión grande pq ya queda marcado
						if (i > 0 || $('.alz-wm-blue-menu').is(':visible')) {
							htmlBreadcrumb = htmlBreadcrumb + '<li class="active">' + array[i] + '</li>\n';
							htmlBreadcrumb = htmlBreadcrumb + '</ol>\n';
						} else {
							document.getElementById('alz-menu-breadcrumb').innerHTML = "";
							htmlBreadcrumb = "";
						}
						setTimeout(function () { }, 30000);
						document.getElementById('alz-menu-breadcrumb').innerHTML = htmlBreadcrumb;
					}
				}

				$('.strMenu').on('click', function (e) {
					//Ponemos nivel 1 y borramos los siguientes niveles si los hubiera
					strMenu = $(this).text();
					arrayBreadcrumb = [strMenu, "", "", ""];
					actualizarBreadcrumb(arrayBreadcrumb, $(this).attr("onclick"));
				});
				$('.strSubmenu').on('click', function (e) {
					//Ponemos nivel 1 y 2 y borramos los siguientes niveles si los hubiera
					strSubmenu = $(this).text();
					arrayBreadcrumb = [strMenu, strSubmenu, "", ""];
					actualizarBreadcrumb(arrayBreadcrumb, $(this).attr("onclick"));
				});
				$('.strSubmenu2').on('click', function (e) {
					//Ponemos nivel 1, 2 y 3 y borramos los siguientes niveles si los hubiera
					strSubmenu2 = $(this).text();
					arrayBreadcrumb = [strMenu, strSubmenu, strSubmenu2, ""];
					actualizarBreadcrumb(arrayBreadcrumb, $(this).attr("onclick"));
				});
				$('.strSubmenu3').on('click', function (e) {
					//Ponemos todos los niveles
					strSubmenu3 = $(this).text();
					arrayBreadcrumb = [strMenu, strSubmenu, strSubmenu2, strSubmenu3];
					actualizarBreadcrumb(arrayBreadcrumb, $(this).attr("onclick"));
				});
			});

			$(document).mouseup(function (e) {
				var containerwm = $('.alz-wm-info-po-markup > .alz-wm-info-po-link');

				if (!containerwm.is(e.target) // if the target of the click isn't the container...
					&& containerwm.has(e.target).length === 0) {
					// ... nor a descendant of the container
					$('.alz-wm-info-po-markup > .alz-wm-info-po-link').popover('hide');
				}

				var container = $('.alz-info-po-markup > .alz-info-po-link');
				if (!container.is(e.target) // if the target of the click isn't the container...
					&& container.has(e.target).length === 0) {
					// ... nor a descendant of the container
					$('.alz-info-po-markup > .alz-info-po-link').popover('hide');
				}
				//hacer desaparecer el menú en caso de clickar fuera del area del menú
				//version desktop
				var menuContainer = $('.activeSubmenu');
				var menuBar = $('#desktopMenu');
				if ($("*").hasClass("activeSubmenu") && !menuContainer.is(e.target) && !menuBar.is(e.target) // if the target of the click isn't the container or the menu...
					&& menuContainer.has(e.target).length === 0 && menuBar.has(e.target).length === 0) {
					// ... nor a descendant of the container
					cleanDesktopMenu();
					$('#desktopMenu span.glyphicon-triangle-top').addClass('hidden');
				}

				//version mobile
				var menuContainer = $('#mobileMenu');
				if ($("#mobileMenu*").hasClass("alz-wm-menu-mobile-collapse") && !menuContainer.is(e.target) // if the target of the click isn't the container or the menu...
					&& menuContainer.has(e.target).length === 0) {
					// ... nor a descendant of the container
					$(".alz-wm-menu-mobile-collapse").removeClass('alz-wm-menu-mobile-collapse').addClass('alz-wm-menu-mobile-collapse-hidden');
				}
			});

			// Event handler for InputDate - datepicker.
			// It prevents the focus event listener of bootstrap-datepicker when there is an error (because the picker comes on top of it
			// and the message cannot be read).
			window.inputDateFocus = function (e) {
				// Find the parent with the errorClass (error container).
				if ($(this).hasClass("alz-wm-inputdate-block-calendar")) {
					// If the input text is configured to block calendar on focus, prevent the event.
					e.stopImmediatePropagation();
				} else {
					// Prevent the showing of the calendar if there is a message error.
					var errorClassParent = $(this).closest('.errorClass');
					if (errorClassParent != null) {
						// Find the error message div.
						var errorBox = $(errorClassParent).find('.ws-errorbox');
						if (errorBox != null && errorBox.css('display') != null && errorBox.css('display') != 'none') {
							// If the error is displayed at the moment, hide the picker (so it doesn't cover the error message).
							e.stopImmediatePropagation();
						}
					}
				}
			};

			// Prevent scrolling with space when focus is in a component that uses space bar to control it.
			// Components with this behaviour: Section Header, Combo, TruncatedTable.
			$(window).keydown(function (e) {
				if (e.which == 32 && (
					// Section Header/Combo item
					e.target.tagName == "A" ||
					// Clickable Image.
					e.target.tagName == "IMG" && $(e.target).hasClass('alz-wm-img-clickable')
					// TruncatedTable row
					|| e.target.tagName == "DIV" && $(e.target).hasClass('alz-wm-tt-content')
					// TruncatedTable footer
					|| e.target.tagName == "DIV" && $(e.target).hasClass('alz-wm-tt-collapse-button')
					// LocationFinder province dropdown.
					|| e.target.tagName == "TD" && $(e.target).hasClass('alz-wm-lf-dropdown-row')
					// Checkbox
					|| e.target.tagName == "LABEL" && $(e.target).hasClass('alz-wm-checkbox-button-label')
					// Radiobutton
					|| e.target.tagName == "LABEL" && $(e.target).hasClass('alz-wm-radio-button-label'))) {
					return false;
				}
			});

			// Allow space to cause a click event.
			window.handleClickBySpacePress = function (e) {
				if (e.keyCode == 32) {
					$(this).click();
				}
			};
			/***/

			// checkboxbutton (buttongroup)
			$("div[class$='alz-btn-group-checkboxbutton'] .alz-wm-bs-btn-group .alz-wm-btn-group__label").click(function (e) {
				var _val = $(this).hasClass('checked');
				var childrens = $(this).parent().parent().children();
				for(var i = 0; i < childrens.length; i++) {
					var id = '#' + childrens[i].children[0].id;
					$(id).removeClass('active');
					$(id).removeClass('checked');
					$(id+'_input').checked = false;
				}
				if (!_val) {
					$(this).addClass('checked');
					$($(this).id + '_input').checked = true;
				}
			});

			$(".alz-wm-bs-btn-group-checkboxicon .alz-checkbox-configurator .alz-checkbox-configurator_label").click(function (e) {
				var isChecked = $(this).hasClass('active');
				var childrens = $(this).parent().parent().children();
				if (!isChecked) {
					for (var i = 0; i < childrens.length; i++) {
						var label = $('#' + childrens[i].children[1].children[1].id).parent();
						$(label).removeClass('active');
						var target = $('#' + childrens[i].children[0].id)
						if (!target.prop('disabled')) {
							target.attr('checked', false);
						}
					}
					$(this).addClass('active');
					$((this).children[0].id).attr('checked', true);
				} else {
					$(this).removeClass('active');
					$((this).children[0].id).attr('checked', false);
				}
			});
}
/******/]);

// Listen to webshim event for resize iframe when an error is shown
$(function () {
	$(document.body).on({
		'changedvaliditystate': function (e) {
			if ($STYLELINE == "styleLine13" && window.self !== window.top) {
				setTimeout(function () {
					Page.doEPacResize();
				}, 1000);
			}
		}
	});
});

$(".alz-wm-btn-group__label").click(function (e) {
	var _val = $(this).is(':checked') ? 'checked' : 'unchecked';
	var childrens = $(this).parent().parent().children();
	if (_val !== 'checked') {
		for (var i = 0; i < childrens.length; i++) {
			var id = '#' + childrens[i].children[0].id;
			$(id).removeClass('active');
			$('#' + childrens[i].children[0].children[0].id).checked = false;
		}
		$(this).addClass('active');
		$((this).children[0].id).checked = true;
	} else {
		$(this).removeClass('active');
		$((this).children[0].id).checked = false;
	}
});